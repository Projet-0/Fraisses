<?php
    get_header();
    
?>    
    <div>
        <h1>
        <?php wp_title(); ?> 
        </h1>

        <?php the_content() ; ?> 
    </div>

    <p>ON va tester s'il détecte les images </p>

    <div>
        <?php 
            if (has_post_thumbnail()) {
                echo "Contient une image de featuer";
            }
        ?>

    </div>

<?php
    get_footer();
?>
