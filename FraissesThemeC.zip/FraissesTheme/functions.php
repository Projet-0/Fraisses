<?php

function fraisses_theme_support(){
    //Add dynamic title tag support
    add_theme_support( 'title-tag');

    add_theme_support('custom-logo');
    
    add_theme_support('post-thumbnails');
}

add_action('after_setup_theme','fraisses_theme_support');


function fraisses_menus(){

    $locations = array(
        'primary' => "Desktop primary NavBar",
        'discover' => "Menu Découvrir",
        'citoyennete' => "Menu Citoyenneté",
        'Sports-Loisirs' => "Menu Sports et Loisirs",
        'Culturelle' => "Menu Culturelle",
        'demarche' => "Menu Vos démarches",
        'footer' => "Footer Menu items",

    );

    register_nav_menus($locations);
}

add_action('init','fraisses_menus');


function fraisses_register_styles(){

    $version = wp_get_theme()->get( 'Version') ;
    wp_enqueue_style('fraisses-style', get_template_directory_uri(). "/style.css", array( 'fraisses-bootstrap') , $version, 'all' );
    wp_enqueue_style('fraisses-bootstrap', "https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css", array() , '1.0', 'all' );
    wp_enqueue_style('fraisses-fontawesome',"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css", array() , '1.0', 'all' );
}

add_action('wp_enqueue_scripts','fraisses_register_styles');

// function fraisses_register_scripts(){

//     wp_enqueue_script('fraisses-bootstrap','https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css',array(), '3.4.1' , true);
// }

// add_action('wp_enqueue_scripts','fraisses_register_scripts');

?>