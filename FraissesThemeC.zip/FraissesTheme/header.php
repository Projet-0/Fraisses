<!DOCTYPE html>

<head>
    <script defer="" type="text/javascript" src="index.js"></script>

    <?php
	wp_head();
	?>
</head>

<body>
    <!-- PROBLEME d'IMPport -->
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/fontawesome.min.css    "></script> -->  
    <div class="panorama">
        <!-- <img src="./assets/Panorama.jpg" /> -->

        <div class="logo">
            <img src="<?php echo get_template_directory_uri(); ?>./assets/images/LogoFraissesFinal.png" class="filter-white" />
        </div>
        <div class="access">
            <div class="icon">
                <div class="item">
                    <img src="<?php echo get_template_directory_uri(); ?>./assets/images/icons/house-solid.svg" />
                    <a href=""><p>Accueil</p></a>
                </div>
                
                <div class="item">
                    <img src="<?php echo get_template_directory_uri(); ?>./assets/images/icons/envelope-solid.svg" />
                    <p>Mag</p>
                </div>
                <div class="item">
                    <img src="<?php echo get_template_directory_uri(); ?>./assets/images/icons/file-regular.svg   " />
                    <p>Démarche en ligne</p>
                </div>
                <div class="item">
                    <img src="<?php echo get_template_directory_uri(); ?>./assets/images/icons/map-solid.svg   " />
                    <a href="./Discover.html"><p>Découvrir la ville</p></a>
                </div>
                <!-- <div class="item">
                    <img src="./assets/icons/water-ladder-solid.svg   " />
                    <p>Piscine</p>
                </div> -->

            </div>
            
            <div class="search-bar"><input type="text" placeholder="Rechercher" class="search"></div>
            
        </div>
        
        
    </div>

    <div class='NavBar'>

        <!-- A TERME ON VERRA POUR EN METTRE UN DANS CHAQUE UL 1.03.26 -->

        <div class='NavBarContainer'>
            <a class="Accueil-btn" href="#"><p>Accueil</p></a>
        </div>
        <div class='NavBarContainer'>
            <a class="Accueil-btn" ><p>Découvrir</p></a>
            <div class="sous-menu">
                <ul class="sous-list">
                    <a href="./pages/decouvrir/presentation.html"><li>Présentation</li></a>
                    <a href=""><li>Carte d'identité</li></a>
                    <a href="./pages/decouvrir/venir.html"><li>venir à Fraisses</li></a>
                    <a href="./pages/decouvrir/environnement.html"><li>Environnement</li></a>
                </ul>
            </div>
        </div>


        <div class='NavBarContainer'>  
        <p>Découvrir</p>
        <div class="sous-menu">
            <ul class="sous-list">
                <li>
            <?php
                wp_nav_menu(
                    array(
                        'menu' => 'primary' ,
                        'container' => '' ,
                        'theme_location' => 'primary',
                        'items_wrap' => '<li>%3$s</li>'
                    )
                );
            ?>
            </ul>
        </div>


        </div>

        <!-- FIN TEST -->


        <div class='NavBarContainer'>
            <p>Citoyenneté</p>
            <div class="sous-menu">
                <ul class="sous-list">
                    <a href=""><li>Horaire d'ouverture</li></a>
                    <a href=""><li>Municipalité</li></a>
                    <a href=""><li>Budget communal</li></a>
                    <a href=""><li>Intercommunalité</li></a>
                    <a href=""><li>Marchés public</li></a>
                    <a href=""><li>Offres d'emploi</li></a>
                    <a href=""><li>Publication légale</li></a>
                </ul>
            </div>
        </div>
        <div class='NavBarContainer'>
            <p>Sports-Loisir</p>
            <div class="sous-menu">
                <ul class="sous-list">
                    <a href="./pages/sports-loisirs/installations.html"><li>Nos installations</li></a>
                    <a href=""><li>Vie associative</li></a>
                    <a href=""><li>Centre de Loisirs</li></a>
                    <a href=""><li>Marche des hameaux</li></a>
                </ul>
            </div>
        </div>
        <div class='NavBarContainer'>
            <p>Culturelle</p>
            <div class="sous-menu">
                <ul class="sous-list">
                    <a href=""><li>Saison Culturelle</li></a>
                    <a href=""><li>Bibliothèque</li></a>
                    <a href=""><li>Location des salles</li></a>
                </ul>
            </div>
        </div>
        <div class='NavBarContainer'>
            <p>Vos démarches</p>
            <div class="sous-menu">
                <ul class="sous-list">
                    <a href=""><li>Démarches service public</li></a>
                    <a href=""><li>Annuaire des commerçants</li></a>
                    <a href=""><li>Annuaire des administrations</li></a>
                    <a href=""><li>Urbanisme</li></a>
                    <a href=""><li>Transport</li></a>
                    <a href=""><li>Crèche - Petite enfance</li></a>
                    <a href=""><li>Vie des écoles</li></a>
                    <a href=""><li>Centre de Loisir</li></a>
                    <a href=""><li>Séniors</li></a>
                    <a href=""><li>Santé</li></a>
                    <a href=""><li>Social</li></a>
                    <a href=""><li>Service de l'eau</li></a>
                    <a href=""><li>Gestion et tri des déchets</li></a>
                    <a href=""><li>Informatique et liberté</li></a>
                </ul>
            </div>
        </div>
    </div>
