        <div class="footer">
            <h1>Nous contacter</h1>
            <div class="contact">
                <div class="contact-item">
                    <h2>Téléphone</h2>
                    <h3>04 77 44 56 40</h3>
                </div>
                <div class="contact-item">
                    <h2>Mail</h2>
                    <h3>contact@fraisses.fr</h3>
                </div>
                <div class="contact-item">
                    <h2>Adresse</h2>
                    <h3>12 Rue Jean Padel <br> 42490 Fraisses </h3>
                </div>
                <div class="contact-item">
                    <h2>Réseaux sociaux</h2>
                    <a href="https://www.facebook.com/people/Mairie-De-Fraisses/100064362176509/"><img src="<?php echo get_template_directory_uri(); ?>./assets/images/icons/facebook-f.svg" /></a>
                </div>
                
            </div>
        </div>

    </div>
</body>


<!-- JS DROPDOWN -->

<!-- DANS Le cas où on veut mettre des scripts -->

<?php
    wp_footer();
?>

<script>
    var dropdown_btn = document.getElementsByClassName("Accueil-btn")

</script>