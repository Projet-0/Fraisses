<div class="moment-item">
    <!-- <img src="" alt="moment"> -->
    <!-- image a display -->
    <?php
        the_post_thumbnail() ;
    ?>
    <h1>Article</h1>
    <!-- <h3>Publié le  <?php the_date()?></h3> -->

    <!-- Le format du contenu qu'on récupère est déjà un paragraphe donc pas besoin de la spécifier -->
    <?php
        the_content();
    ?>

    <h5>article en lien avec : <?php the_tags(); ?></h5>

</div>

