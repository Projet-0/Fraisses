<?php
        get_header();
    ?>

    <div class="background-set">




        <div class="main">
            <div class="main-image"><img src="<?php echo get_template_directory_uri(); ?>./assets/images/bibliothèque.jpg" alt="img a la une"></div>
            <div class="main-text">
                <h1>À la une </h1>
                <h2>Nouvelle exposition </h2>
                <p>Retrouvez l’ensemble des activités proposées par le Centre de Loisirs sur le portail famille. Accédez au portail famille pour vous inscrire. Vous désirez vous connecter au portail famille afin d’effectuer vos réservations et. Retrouvez l’ensemble des activités proposées par le Centre de Loisirs sur le portail famille. Lorem ipsum dolor sit amet consectetur adipisicing elit. Sint, distinctio commodi? Recusandae quae nisi, saepe porro vero minima accusantium cumque optio excepturi explicabo, incidunt laudantium unde laborum hic quia atque.</p>
            </div>

            <!-- TEST R2CUP LES POSTS -->
            

            <!-- FIN TEST -->
            
        </div>

        <!-- A terme on va definir un composant image-title-description que l'on pourra appeler a terme pour les différents blocs -->
        
        <div class="moment">
            <h1>En ce moment </h1>

            <div class="moment-content">
                <div class="moment-item">
                    <img src="<?php echo get_template_directory_uri(); ?>./assets/images/tableau.jfif" alt="moment">
                    <h1>Titre du moment</h1>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eum consequuntur impedit iste porro modi nesciunt dolores, obcaecati nisi doloribus, veritatis, aliquid ad eveniet at nostrum voluptatem quasi. Animi, veniam nam.</p>
                </div>
                <div class="moment-item">
                    <img src="<?php echo get_template_directory_uri(); ?>./assets/images/route.jpg" alt="moment">
                    <h1>Titre du moment</h1>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eum consequuntur impedit iste porro modi nesciunt dolores, obcaecati nisi doloribus, veritatis, aliquid ad eveniet at nostrum voluptatem quasi. Animi, veniam nam.</p>
                </div>
                <div class="moment-item">
                    <img src="<?php echo get_template_directory_uri(); ?>./assets/images/nature.jpg   " alt="moment">
                    <h1>Titre du moment</h1>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eum consequuntur impedit iste porro modi nesciunt dolores, obcaecati nisi doloribus, veritatis, aliquid ad eveniet at nostrum voluptatem quasi. Animi, veniam nam.</p>
                </div>

                <!-- DEBUT  RECUPERATION DES POSTS -->
                <?php
                    if( have_posts() ) {
                        while( have_posts() ) {
                            the_post();   
                            // On va chercher le template dans le dossier template-parts pour afficher le blog comme on le veut. en deuxieme argument c'est le type
                            // Ici il va donc chercher content-article au lieu d'aller chercher uniquement le dossier content (si pas de deuxieme)
                            get_template_part('template-parts/content', 'article') ;

                        }
                    }
                ?>

        <!-- FIN RECUPERATION DES POSTS -->    
        </div>
            <!-- <div class="moment-image"><img src="./assets/bibliothèque.jpg" alt="img a la une"></div> -->
            

    </div>

    <?php
        get_footer();
    ?>
