<?php
    get_header();
    
?>

<!-- <?php
    echo 'ca ne s affiche que pour la citoyenneté'; 

?>  -->

<div>
    <h1>
    Horaires d’ouverture
    </h1>
    <p>
        Horaires d’ouverture
        Les services de la mairie sont ouverts du lundi au jeudi de 8h00 à 12h00 et de 13h30 (14h le mardi) à 17h30 et le vendredi de 8h00 à 16h00.

        Pendant les mois de juillet et août, les horaires sont du lundi au vendredi 8h00 à 16h00.
    </p>

        <div>
            <h5>Documents à télécharger</h5>
        </div>

        <div class="download_display">
            <div class="download-item"> 
                <a href="<?php echo get_template_directory_uri(); ?>./assets/download/Tableau_du_conseil_municipal.doc" download>
                            <img class="download" src="<?php echo get_template_directory_uri(); ?>./assets/images/icons/file-pdf-solid.svg" alt="image ne saffiche pas" />
                </a>
            </div>
            <div class="download-item"> 
                <a href="<?php echo get_template_directory_uri(); ?>./assets/download/Tableau_du_conseil_municipal.doc" download>
                            <img class="download" src="<?php echo get_template_directory_uri(); ?>./assets/images/icons/file-pdf-solid.svg" alt="image ne saffiche pas" />
                </a>
            </div>
            <div class="download-item"> 
                <a href="<?php echo get_template_directory_uri(); ?>./assets/download/Tableau_du_conseil_municipal.doc" download>
                            <img class="download" src="<?php echo get_template_directory_uri(); ?>./assets/images/icons/file-pdf-solid.svg" alt="image ne saffiche pas" />
                </a>
            </div>
        </div>
        

</div>

<?php
    get_footer();
        
?> 


<style>
    .download {
        width: 50px;
        height: 50px;
    }

    .download_display {
        display: flex;
        flex-direction: row;
    }

    .download-item{
        padding: 5px;
    }

    

</style>